import Passgen from './passgen';

function App() {
 



  return (
<div>
  <Passgen/>
</div>
  );
};

export default App
